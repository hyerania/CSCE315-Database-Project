In order to clone the repo:

git clone https://github.tamu.edu/kevinjnguyen/CSCE-315-Database-Project.git