Because the dataset is so large, we used the following techniques:

1. We used .007153% of the business data. This rounds to about 8 KB. We chose to use 10 different businesses.

2. We used .027552% of the user data. This rounds to about 317 KB. We chose to use 117 different users.

3. We used .002721% of the review data. For the review data, we used the review data that matches both of the business and user data. This rounds to about 92 KB. We chose 117 different reviews.